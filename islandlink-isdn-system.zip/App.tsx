
import React, { useState, useEffect } from 'react';
import { User, UserRole, Region, Order, Product } from './types';
import { PRODUCTS, MOCK_ORDERS } from './constants';
import { 
  LayoutDashboard, 
  ShoppingBag, 
  Package, 
  Truck, 
  BarChart3, 
  LogOut, 
  User as UserIcon, 
  Box, 
  Bell, 
  CreditCard,
  MapPin,
  TrendingUp,
  AlertCircle
} from 'lucide-react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  LineChart, 
  Line 
} from 'recharts';
import { getSalesInsights } from './geminiService';

// --- Sub-components ---

const SidebarItem = ({ icon: Icon, label, active, onClick }: { icon: any, label: string, active: boolean, onClick: () => void }) => (
  <button 
    onClick={onClick}
    className={`flex items-center space-x-3 w-full p-3 rounded-lg transition-colors ${
      active ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-200' : 'text-slate-500 hover:bg-slate-100'
    }`}
  >
    <Icon size={20} />
    <span className="font-medium text-sm">{label}</span>
  </button>
);

const StatCard = ({ title, value, icon: Icon, trend }: { title: string, value: string | number, icon: any, trend?: string }) => (
  <div className="bg-white p-6 rounded-xl border border-slate-100 shadow-sm flex items-start justify-between">
    <div>
      <p className="text-slate-500 text-sm font-medium mb-1">{title}</p>
      <h3 className="text-2xl font-bold text-slate-800">{value}</h3>
      {trend && <p className="text-emerald-500 text-xs mt-2 font-semibold">↑ {trend}</p>}
    </div>
    <div className="p-3 bg-indigo-50 text-indigo-600 rounded-lg">
      <Icon size={24} />
    </div>
  </div>
);

// --- Main Views ---

const Login = ({ onLogin }: { onLogin: (role: UserRole, region?: Region) => void }) => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center p-4">
      <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl p-8 space-y-8">
        <div className="text-center">
          <div className="inline-flex p-3 bg-indigo-100 text-indigo-600 rounded-xl mb-4">
            <Box size={32} />
          </div>
          <h1 className="text-3xl font-bold text-slate-800 tracking-tight">IslandLink ISDN</h1>
          <p className="text-slate-500 mt-2">Centralized Sales Distribution System</p>
        </div>

        <div className="space-y-4">
          <p className="text-center text-sm font-medium text-slate-400 uppercase tracking-widest">Select Role to Demo</p>
          <button onClick={() => onLogin(UserRole.HEAD_OFFICE)} className="w-full py-3 bg-slate-800 text-white rounded-xl font-semibold hover:bg-slate-700 transition">Head Office Manager</button>
          <button onClick={() => onLogin(UserRole.RETAIL_CUSTOMER)} className="w-full py-3 border-2 border-slate-100 text-slate-700 rounded-xl font-semibold hover:bg-slate-50 transition">Retail Customer (Central)</button>
          <button onClick={() => onLogin(UserRole.RDC_STAFF, Region.SOUTH)} className="w-full py-3 border-2 border-slate-100 text-slate-700 rounded-xl font-semibold hover:bg-slate-50 transition">RDC South Staff</button>
          <button onClick={() => onLogin(UserRole.LOGISTICS)} className="w-full py-3 border-2 border-slate-100 text-slate-700 rounded-xl font-semibold hover:bg-slate-50 transition">Logistics Team</button>
        </div>
        
        <p className="text-xs text-center text-slate-400">Secured with Enterprise-grade AES Encryption</p>
      </div>
    </div>
  );
};

const DashboardHO = () => {
  const [aiInsight, setAiInsight] = useState("Analyzing current trends...");
  
  useEffect(() => {
    getSalesInsights(MOCK_ORDERS).then(setAiInsight);
  }, []);

  const chartData = [
    { name: 'North', sales: 4500, stock: 2100 },
    { name: 'South', sales: 5200, stock: 1800 },
    { name: 'East', sales: 3800, stock: 1500 },
    { name: 'West', sales: 4900, stock: 2200 },
    { name: 'Central', sales: 8500, stock: 4000 },
  ];

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard title="Total Monthly Sales" value="LKR 4.2M" icon={BarChart3} trend="12.5% vs last month" />
        <StatCard title="Active Retailers" value="5,248" icon={UserIcon} trend="3% growth" />
        <StatCard title="Delivery Efficiency" value="98.2%" icon={Truck} trend="2.1% improvement" />
        <StatCard title="Total Inventory Value" value="LKR 18M" icon={Package} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-white p-6 rounded-xl border border-slate-100 shadow-sm">
          <h4 className="font-bold text-slate-800 mb-6 flex items-center">
            <TrendingUp size={18} className="mr-2 text-indigo-600" />
            Regional Performance & Inventory
          </h4>
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="sales" fill="#4f46e5" radius={[4, 4, 0, 0]} name="Sales (LKR)" />
                <Bar dataKey="stock" fill="#94a3b8" radius={[4, 4, 0, 0]} name="Stock Units" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-indigo-900 text-white p-6 rounded-xl shadow-lg flex flex-col justify-between">
          <div>
            <h4 className="font-bold mb-4 flex items-center">
              <AlertCircle size={18} className="mr-2 text-indigo-300" />
              AI Distribution Insight
            </h4>
            <p className="text-indigo-100 text-sm leading-relaxed italic">
              "{aiInsight}"
            </p>
          </div>
          <button className="mt-6 w-full py-2 bg-indigo-500 hover:bg-indigo-400 transition text-white rounded-lg text-sm font-semibold">
            Run Optimization Model
          </button>
        </div>
      </div>
    </div>
  );
};

const ProductCatalog = ({ userRegion }: { userRegion: Region }) => {
  const [cart, setCart] = useState<Record<string, number>>({});
  
  const addToCart = (id: string) => {
    setCart(prev => ({ ...prev, [id]: (prev[id] || 0) + 1 }));
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold text-slate-800">Product Catalog</h2>
        <div className="flex items-center space-x-2 text-sm text-slate-500">
          <MapPin size={16} />
          <span>Servicing from <strong>{userRegion} RDC</strong></span>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {PRODUCTS.map(p => (
          <div key={p.id} className="bg-white rounded-xl border border-slate-100 overflow-hidden hover:shadow-md transition group">
            <div className="h-48 relative overflow-hidden">
              <img src={p.image} alt={p.name} className="w-full h-full object-cover group-hover:scale-105 transition duration-500" />
              <div className="absolute top-3 left-3 bg-white/90 backdrop-blur px-2 py-1 rounded-md text-[10px] font-bold uppercase tracking-wider text-slate-600">
                {p.category}
              </div>
            </div>
            <div className="p-4">
              <h3 className="font-bold text-slate-800 truncate">{p.name}</h3>
              <div className="flex items-center justify-between mt-2">
                <span className="text-indigo-600 font-bold">LKR {p.price.toLocaleString()}</span>
                <span className={`text-[10px] font-medium px-2 py-0.5 rounded-full ${p.stock[userRegion] > 50 ? 'bg-emerald-50 text-emerald-600' : 'bg-red-50 text-red-600'}`}>
                  {p.stock[userRegion]} in stock
                </span>
              </div>
              <button 
                onClick={() => addToCart(p.id)}
                className="mt-4 w-full py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-sm font-medium flex items-center justify-center space-x-2 transition"
              >
                <ShoppingBag size={16} />
                <span>Add to Order</span>
              </button>
            </div>
          </div>
        ))}
      </div>
      
      {Object.keys(cart).length > 0 && (
        <div className="fixed bottom-8 right-8 bg-indigo-600 text-white p-4 rounded-2xl shadow-2xl flex items-center space-x-6 animate-bounce">
          <div className="flex items-center space-x-3">
            <div className="bg-white/20 p-2 rounded-lg">
              <ShoppingBag size={20} />
            </div>
            <div>
              <p className="text-[10px] font-bold uppercase opacity-70">Items in Cart</p>
              {/* Added explicit type casting to fix 'unknown' type error in reduce operation */}
              <p className="font-bold">{(Object.values(cart) as number[]).reduce((a, b) => a + b, 0)} Items</p>
            </div>
          </div>
          <button className="bg-white text-indigo-600 px-6 py-2 rounded-xl font-bold hover:bg-slate-100 transition">
            Place Order
          </button>
        </div>
      )}
    </div>
  );
};

const InventoryManager = ({ region }: { region: Region }) => {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-slate-800">RDC Inventory: {region}</h2>
          <p className="text-slate-500 text-sm">Real-time stock synchronization active</p>
        </div>
        <button className="bg-indigo-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-indigo-700">
          Initiate Inter-branch Transfer
        </button>
      </div>

      <div className="bg-white rounded-xl border border-slate-100 shadow-sm overflow-hidden">
        <table className="w-full text-left">
          <thead className="bg-slate-50 border-b border-slate-100">
            <tr>
              <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase">Product</th>
              <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase">Category</th>
              <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase">Current Stock</th>
              <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase">Last Sync</th>
              <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {PRODUCTS.map(p => (
              <tr key={p.id} className="hover:bg-slate-50 transition">
                <td className="px-6 py-4 flex items-center space-x-3">
                  <div className="w-10 h-10 rounded bg-slate-100 flex-shrink-0">
                    <img src={p.image} className="w-full h-full object-cover rounded" />
                  </div>
                  <span className="font-medium text-slate-800">{p.name}</span>
                </td>
                <td className="px-6 py-4 text-sm text-slate-600">{p.category}</td>
                <td className="px-6 py-4">
                  <div className="flex items-center space-x-2">
                    <span className="font-bold text-slate-800">{p.stock[region]}</span>
                    <div className="w-24 h-2 bg-slate-100 rounded-full overflow-hidden">
                      <div 
                        className={`h-full ${p.stock[region] < 150 ? 'bg-red-500' : 'bg-indigo-500'}`}
                        style={{ width: `${Math.min(100, (p.stock[region] / 1000) * 100)}%` }}
                      ></div>
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4 text-sm text-slate-400 italic">2 mins ago</td>
                <td className="px-6 py-4 text-right">
                  <button className="text-indigo-600 font-semibold text-sm hover:underline">Update</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

const LogisticsTracker = () => {
  return (
    <div className="space-y-6">
      <h2 className="text-xl font-bold text-slate-800">Fleet & Delivery Tracking</h2>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-slate-200 rounded-2xl h-[500px] relative overflow-hidden shadow-inner flex items-center justify-center">
          {/* Simulated Map UI */}
          <div className="absolute inset-0 opacity-20 pointer-events-none bg-[url('https://www.transparenttextures.com/patterns/graphy.png')]"></div>
          <div className="relative z-10 text-slate-400 flex flex-col items-center">
            <MapPin size={48} className="animate-bounce text-indigo-500 mb-2" />
            <p className="font-bold text-slate-500">Live GPS Grid Island View</p>
            <p className="text-xs">12 Active Vehicles Monitored</p>
          </div>
          
          {/* Mock Markers */}
          <div className="absolute top-1/4 left-1/2 -translate-x-1/2 bg-white px-3 py-1 rounded-full shadow-lg border border-indigo-100 flex items-center space-x-2">
            <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></div>
            <span className="text-xs font-bold text-slate-700">VAN-01 (En Route Central)</span>
          </div>
          <div className="absolute bottom-1/3 left-1/3 bg-white px-3 py-1 rounded-full shadow-lg border border-indigo-100 flex items-center space-x-2">
            <div className="w-2 h-2 bg-indigo-500 rounded-full animate-pulse"></div>
            <span className="text-xs font-bold text-slate-700">TRUCK-05 (Loading South)</span>
          </div>
        </div>

        <div className="space-y-4">
          <h3 className="font-bold text-slate-700 flex items-center">
            <Truck size={18} className="mr-2" />
            Active Shipments
          </h3>
          {[1,2,3,4].map(i => (
            <div key={i} className="bg-white p-4 rounded-xl border border-slate-100 shadow-sm hover:border-indigo-200 transition">
              <div className="flex justify-between items-start mb-2">
                <span className="text-xs font-bold text-slate-400">#ORD-092{i}</span>
                <span className="bg-emerald-50 text-emerald-600 text-[10px] font-bold px-2 py-0.5 rounded uppercase">In Transit</span>
              </div>
              <p className="font-bold text-slate-800 text-sm">Main Street Supermarket</p>
              <div className="mt-3 flex items-center justify-between text-xs">
                <span className="text-slate-500">Est. Arrival</span>
                <span className="font-bold text-slate-800">14:45 PM</span>
              </div>
              <div className="mt-2 w-full h-1.5 bg-slate-100 rounded-full overflow-hidden">
                <div className="h-full bg-indigo-500 w-3/4"></div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

// --- Main App Logic ---

export default function App() {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [activeTab, setActiveTab] = useState('dashboard');

  const handleLogin = (role: UserRole, region: Region = Region.CENTRAL) => {
    setCurrentUser({
      id: Math.random().toString(36).substr(2, 9),
      name: `Demo ${role.replace('_', ' ').toLowerCase()}`,
      role,
      region
    });
    // Set initial tab based on role
    if (role === UserRole.RETAIL_CUSTOMER) setActiveTab('products');
    else if (role === UserRole.RDC_STAFF) setActiveTab('inventory');
    else if (role === UserRole.LOGISTICS) setActiveTab('logistics');
    else setActiveTab('dashboard');
  };

  const handleLogout = () => {
    setCurrentUser(null);
  };

  if (!currentUser) {
    return <Login onLogin={handleLogin} />;
  }

  return (
    <div className="min-h-screen flex">
      {/* Sidebar */}
      <aside className="w-64 bg-white border-r border-slate-100 flex flex-col sticky top-0 h-screen hidden lg:flex">
        <div className="p-6">
          <div className="flex items-center space-x-3 text-indigo-600 mb-8">
            <Box size={32} />
            <span className="font-bold text-xl tracking-tight text-slate-800">IslandLink</span>
          </div>

          <nav className="space-y-2">
            {(currentUser.role === UserRole.HEAD_OFFICE || currentUser.role === UserRole.RDC_STAFF) && (
              <SidebarItem 
                icon={LayoutDashboard} 
                label="Overview" 
                active={activeTab === 'dashboard'} 
                onClick={() => setActiveTab('dashboard')} 
              />
            )}
            {currentUser.role !== UserRole.LOGISTICS && (
              <SidebarItem 
                icon={ShoppingBag} 
                label="Products" 
                active={activeTab === 'products'} 
                onClick={() => setActiveTab('products')} 
              />
            )}
            <SidebarItem 
              icon={Package} 
              label="Inventory" 
              active={activeTab === 'inventory'} 
              onClick={() => setActiveTab('inventory')} 
            />
            <SidebarItem 
              icon={Truck} 
              label="Logistics" 
              active={activeTab === 'logistics'} 
              onClick={() => setActiveTab('logistics')} 
            />
            <SidebarItem 
              icon={CreditCard} 
              label="Payments" 
              active={activeTab === 'billing'} 
              onClick={() => setActiveTab('billing')} 
            />
          </nav>
        </div>

        <div className="mt-auto p-6 border-t border-slate-50 space-y-4">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-600">
              <UserIcon size={20} />
            </div>
            <div className="flex-1 overflow-hidden">
              <p className="text-sm font-bold text-slate-800 truncate">{currentUser.name}</p>
              <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">
                {currentUser.role.replace('_', ' ')} {currentUser.region ? `(${currentUser.region})` : ''}
              </p>
            </div>
          </div>
          <button 
            onClick={handleLogout}
            className="flex items-center space-x-3 w-full p-2 text-slate-400 hover:text-red-500 transition-colors"
          >
            <LogOut size={18} />
            <span className="text-sm font-medium">Sign Out</span>
          </button>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col">
        {/* Header */}
        <header className="bg-white/80 backdrop-blur border-b border-slate-100 sticky top-0 z-30 px-8 py-4 flex items-center justify-between">
          <div>
            <h2 className="text-lg font-bold text-slate-800 capitalize">{activeTab}</h2>
            <p className="text-xs text-slate-500">Island-wide Sales Distribution Network v2.0</p>
          </div>
          <div className="flex items-center space-x-4">
            <button className="p-2 text-slate-400 hover:bg-slate-50 rounded-lg relative">
              <Bell size={20} />
              <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full border-2 border-white"></span>
            </button>
          </div>
        </header>

        {/* Dynamic Content */}
        <div className="p-8">
          {activeTab === 'dashboard' && <DashboardHO />}
          {activeTab === 'products' && <ProductCatalog userRegion={currentUser.region || Region.CENTRAL} />}
          {activeTab === 'inventory' && <InventoryManager region={currentUser.region || Region.CENTRAL} />}
          {activeTab === 'logistics' && <LogisticsTracker />}
          {(activeTab === 'billing' || activeTab === 'orders') && (
            <div className="bg-white p-12 rounded-2xl border border-dashed border-slate-200 flex flex-col items-center justify-center text-center">
              <CreditCard size={48} className="text-slate-200 mb-4" />
              <h3 className="text-xl font-bold text-slate-800">Payment Gateway Integration</h3>
              <p className="text-slate-500 mt-2 max-w-sm">Securely connecting to local banking gateways for automated digital invoicing and collections.</p>
              <button className="mt-6 px-6 py-2 bg-indigo-600 text-white rounded-lg font-medium shadow-lg shadow-indigo-100">Configure Gateways</button>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
